1. This is a standard Maven Project
2. Source code is in folder "src"
3. A runnable jar can be found in folder "target"
4. Run the demo by double clicking the jar file "target\PolishNotationStackMachine-1.0.0-SNAPSHOT.jar"
5. Generated Java Doc is in folder "target\site\apidocs\index.html"
6. Can easly import this project in Netbean or Eclipse IDE by "Import Existing Maven Project"
7. The core bussiness logic is in "StackMachine Class". Two stacks as the data structures to store input elements and log the commands
